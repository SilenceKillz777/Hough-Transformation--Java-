
public class Point {

	int row;
	int col;
	
}
